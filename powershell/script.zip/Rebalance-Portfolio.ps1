param (
    [string]$filename
)

# Define the desired stock allocation
$target_allocations = @{
    "US Stocks"=@{ "FZROX"=.32; };
    "International Stocks"=@{ "FZILX"=.2; };
    "Bonds"=@{ "FTBFX"=.2 };
    "REIT"=@{ "FSRNX"=.08 };
    "Cash"=@{ "SPAXX**"=.1 };
    "Fun Stocks"=@{ "TSLA"=.1 };
}

# Flatten the list of stocks -> allocation percentages
$asset_allocations = @{}
$sanity_sum = 0

foreach ($bucket in $target_allocations.Keys) {
    foreach ($symbol in $target_allocations[$bucket].Keys) {
        if ($bucket -ne "Cash") { # don't count the cash bucket, cleans up output later
            $asset_allocations.Add($symbol, $target_allocations.Item($bucket).Item($symbol))
        }
        $sanity_sum =  $sanity_sum + $target_allocations.Item($bucket).Item($symbol)
    }
}

write-host $sanity_sum
write-host $sanity_sum.GetType()
if ($sanity_sum -eq 1) {
    write-host ("Your target allocations sum to {0}!" -f $sanity_sum) -ForegroundColor Red
    exit
} else {
    "1 != 1"
    exit
}

$csv = import-csv "$filename"

$positions = $csv | where-object { $_.symbol.length -gt 1 }
$positions | foreach-object -process {
    $_.'Current Value' = $_.'Current Value' -replace '[^\d.]'
}

$total_portfolio_value = ($positions | measure-object 'Current Value' -sum).Sum

write-host ("Total Portfolio Value: {0}" -f $total_portfolio_value)
write-host ""

$positions | foreach-object {
    if ($asset_allocations.containskey($_.symbol)) {
        $target = $asset_allocations.Item($_.symbol)*$total_portfolio_value

        write-host ("Symbol: {0}    Current Value: {1}    Target Value: {2}" -f $_.symbol, $_.'Current Value', $target)
        if ($target -gt $_.'Current Value') {
            write-host ("BUY $ {0} OF {1}" -f ($target - $_.'Current Value'), $_.symbol) -ForegroundColor Green
        } else {
            write-host ("SELL $ {0} OF {1}" -f ($_.'Current Value' - $target), $_.symbol) -ForegroundColor Red
        }
    }
}